package com.mycompany.looca2.controller;

public class EquipamentoDAO {
}
